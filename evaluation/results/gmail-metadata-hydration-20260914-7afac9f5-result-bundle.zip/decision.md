# Gmail metadata hydration benchmark decision

- Selected: `B20W1` (transport=BATCH, B=20, W=1)
- Provider sweep: 100/100 attempted, p95=2001.98ms, HTTP mean=2.00
- Local API confirmation: 100/100 attempted, p95=1750.28ms
- J=2: 50/50 episodes, backend p95=2791.13ms, during-probe p95=30.08ms
- Production `execute_read_node` confirmation on a fixed June 2026 fixture:
  - S3: 100/100 comparable, p50=4512.48ms, p95=5400.75ms, HTTP mean=21.00
  - B20W1: 100/100 comparable, p50=1502.76ms, p95=1987.24ms, HTTP mean=2.00
  - B20W1 p95 improvement: 63.20%; dataset drift/errors/rate limits/timeouts=0
  - Logical Provider calls remained 21.00 and cache result count/order/metadata/page token matched.
- Provider Gmail WRITE/SEND: 0
- Dataset query, resource IDs, Gmail text, OAuth material, and Authorization headers were not persisted.

Selection follows contract/reliability first, Pareto filtering, then the predeclared tie range `max(50ms, 10% of fastest valid p95)` with CPU and implementation simplicity as tie-breakers. The conclusion is local to this PC, account, fixed N=20 metadata fixture, and observed network period.

Reaggregate:

```powershell
.\.venv\Scripts\python.exe scripts\benchmark_gmail_metadata_hydration.py summarize-provider --result-dir "C:\project\google-work-agent\evaluation\results\gmail-metadata-hydration-20260914-7afac9f5"
.\.venv\Scripts\python.exe scripts\benchmark_gmail_metadata_hydration.py summarize-backend --result-dir "C:\project\google-work-agent\evaluation\results\gmail-metadata-hydration-20260914-7afac9f5"
.\.venv\Scripts\python.exe scripts\benchmark_gmail_metadata_hydration.py summarize-concurrent --result-dir "C:\project\google-work-agent\evaluation\results\gmail-metadata-hydration-20260914-7afac9f5"
.\.venv\Scripts\python.exe -m scripts.benchmark_gmail_execute_read_node --result-dir "C:\project\google-work-agent\evaluation\results\gmail-metadata-hydration-20260914-7afac9f5\node-session-003-fixed-june" --aggregate-only
```

The valid node raw results are under `node-session-003-fixed-june/`. Moving-latest exploratory
sessions are preserved separately as dataset-drift diagnostics and are excluded from all final
performance conclusions. Windows did not expose the requested per-process context-switch counter,
so that metric is `null`. One B20W1 resource sample observed a transient 10-process/152-thread
overlap during per-trial runtime teardown; the other 99 B20W1 samples had at most 28 threads at
p95 and the separate persistent Local API J=2 lane showed settled resource stability.
