"""Product-external evaluation workspace."""
